# Correct the stale ServiceCoreConfig constructor

Apply this patch/ overlay to /Users/stefanorocco/apps/service-core-old2.
Only the test constructor changes: removes batch/lease arguments and preserves
500ms polling and 5s drain. No production changes, compilation or tests.

<!-- PATCH-FILES-BEGIN -->
- `README-PATCH.md`
- `application/src/test/java/sdk/composition/ServiceDeploymentCapabilityMatrixTest.java`
- `cleanup.sh`
<!-- PATCH-FILES-END -->
