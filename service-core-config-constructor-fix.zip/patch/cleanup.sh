#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' 'No source deletions required.'
