package sdk.composition;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import sdk.config.KafkaRuntimeConfig;
import sdk.config.ObservabilityRuntimeConfig;
import sdk.config.PostgresRuntimeConfig;
import sdk.config.RetryRuntimeConfig;
import sdk.config.ServiceRuntimeConfig;
import sdk.infra.transport.http.netty.NettyHttpServerConfig;
import sdk.outbox.service.ServiceCoreConfig;
import sdk.persistence.ReliabilityStoreTargets;
import sdk.persistence.StoreTarget;

/** Executable behavioral contract for typed service-builder capabilities. */
class ServiceDeploymentCapabilityMatrixTest {

    @Test
    void authoritativeMayBindMultipleKafkaTopicsToDifferentDeserializers() {
        ServiceRuntimeConfig config = config("authoritative-multi-topic");

        ServiceBuilder.authoritative(
                config)
                .reliabilityStores(reliabilityStores())
                .eventStoreSerializer(value -> String.valueOf(value).getBytes(StandardCharsets.UTF_8))
                .consumeFrom("inventory.events", (_source, type, payload) -> new String(payload, StandardCharsets.UTF_8))
                .consumeFrom("pricing.events", (_source, type, payload) -> new String(payload, StandardCharsets.UTF_8));
    }

    @Test
    void projectorRejectsASecondKafkaSourceTopic() {
        ServiceRuntimeConfig config = config("projector-single-topic");

        ProjectorServiceBuilder builder = ServiceBuilder.projector(
                config)
                .consumeFrom(
                        "sellable.events",
                        (_source, type, payload) -> new String(payload, StandardCharsets.UTF_8));

        assertThrows(
                ServiceCompositionException.class,
                () -> builder.consumeFrom(
                        "pricing.events",
                        (_source, type, payload) -> new String(payload, StandardCharsets.UTF_8)));
    }

    private static ReliabilityStoreTargets reliabilityStores() {
        return new ReliabilityStoreTargets(
                StoreTarget.named("outbox_event"),
                StoreTarget.named("inbox_event"),
                StoreTarget.named("inbound_failure"),
                StoreTarget.named("command_execution"));
    }

    private static ServiceRuntimeConfig config(String clientId) {
        return new ServiceRuntimeConfig(
                "capability-test",
                new PostgresRuntimeConfig(
                        "jdbc:postgresql://localhost/capability_test",
                        "test",
                        "TEST_PASSWORD"),
                new KafkaRuntimeConfig(
                        "localhost:9092",
                        "capability-test-group",
                        clientId,
                        "domain-events",
                        "snapshot-events",
                        Duration.ofMillis(10),
                        Duration.ofSeconds(1),
                        Duration.ofSeconds(1),
                        Duration.ofSeconds(1),
                        Duration.ofMillis(10),
                        "worker",
                        Map.of()),
                new NettyHttpServerConfig(
                        "127.0.0.1",
                        18081,
                        1024,
                        1,
                        8,
                        Duration.ofSeconds(1),
                        Duration.ZERO),
                new ServiceCoreConfig(
                        Duration.ofMillis(500),
                        Duration.ofSeconds(5)),
                new RetryRuntimeConfig(List.of(Duration.ZERO)),
                new ObservabilityRuntimeConfig(false, false, false));
    }
}
